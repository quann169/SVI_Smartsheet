
- Config.xlsx
	+ Staff
		+ Fill info of all user
	+ Config
		+ Select item and option
		+ Define header name of all sheets
- Double click to Run.exe
- Log Directory: Show skip row of each sheet
- TimeSheet.xls: Result