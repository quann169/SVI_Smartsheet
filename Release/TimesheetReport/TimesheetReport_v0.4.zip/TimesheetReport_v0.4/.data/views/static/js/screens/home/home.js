$(document).ready( function () {
	load_datatable('#home_table');
});
