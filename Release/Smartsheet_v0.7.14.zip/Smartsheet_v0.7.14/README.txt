NOTE:
  - Send mail:
	  - Apply for 'vantran' and 'phuongtruong' only
	  - Install and sign in to Outlook 
	  - Timesheets reports will be get info in sheet Report of file TimeSheet.xlsx, review results before confirm to send mail
Usage:
Config.xlsx:
	Sheet:
		Staff:
			Resource: Name of user on smartsheet (Assigned to)
			FullName: Full name of user
			Type:
			Role:
			Other Info:
				Other info about user (mail, other name on smartsheet)
				Ex: Toan Nguyen, toannguyen@savarti.com, Toan
			Manager (mail):
				Address will be receive mail
				Ex: example1@savarti.com, example2@savarti.com
			Exclude:
				Not caculate working time of this user( apply for Weekly/Monthly  Project, Weekly/Monthly Timesheet)
				Ex: 1 or 0, 1 is exclude
		Config:
			Start/End date: caculate working hours in this range
			Email notification (date): report timesheet by this week (default is current week)
			CC (mail):
				Ex: example1@gmail.com, example2@savarti.com
			List sheet: define header name of sheet
		Time-Off: Request to leave of absence
		Holiday: List holiday of year
TimeSheet.xlsx:
	Define color:
		Green: is equal weekly/monthly hours
		Orange: is greater weekly/monthly hours
		Tan: is less weekly/monthly hours
