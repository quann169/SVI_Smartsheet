var SESSION_SIDEBAR = 'sidebar';
var SESSION_FROM 	= 'from';
var SESSION_TO 		= 'to';
var SESSION_FILTER  = 'filter';
var SESSION_SHEETS  = 'sheets';
var SESSION_FILE_NAME  = 'file_name';
var INTERVAL_GET_DATA  = null;